# circle-flags

Flags in a circle shape, with a transparent background.

Original Repository: https://github.com/HatScripts/circle-flags \
Fork Repository: https://github.com/CCBlueX/circle-flags

Includes all recognized countries using the ISO 3166-1 alpha-2 two-letter country codes.

# License
This project is licensed under the MIT License. See the [LICENSE](LICENSE.md) file for details.
